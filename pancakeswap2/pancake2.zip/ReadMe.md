# PancakeSwap-Clone

## Description
The pancakeswap-clone is just to exercise my ability to recreate pancakeswap website.\
### Note: This Project is for testing purposes.

## Usage

To test this project is straight forward:
- Clone this
- Load the index.html file in a browser. 